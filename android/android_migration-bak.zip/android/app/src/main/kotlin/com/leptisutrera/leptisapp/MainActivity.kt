package com.leptisutrera.leptisapp

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
